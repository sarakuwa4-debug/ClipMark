# Clipmark

A small website that reads a YouTube video's captions, ranks the most clip-worthy moments, and renders the ones you pick as vertical 9:16 MP4s from **a video file you own or have permission to edit**. It never downloads from YouTube.

## Run locally
```
pip install -r requirements.txt   # also needs FFmpeg on your PATH
python app.py                     # http://localhost:8080
```

## Deploy
- **Replit:** upload the files, keep `replit.nix` (installs FFmpeg), press Run, then use Deploy.
- **Render:** upload the project to GitHub, then use **New → Blueprint** and select the repository. Render reads `render.yaml` and builds the included Dockerfile with FFmpeg. You can also choose **New → Web Service**, select Docker, and use `Dockerfile`.
- The included Render configuration uses the free plan, one Gunicorn worker, a 100 MB upload limit, and `/healthz` as its health check.

## Settings (environment variables)
| Name | Purpose |
|---|---|
| `PROXY_URL` | Proxy for caption requests. YouTube often blocks cloud-host IPs; set this if you see the "blocking caption requests" error. |
| `MAX_UPLOAD_MB` | Largest upload accepted (default 100). |
| `PORT` | Port to listen on (default 8080). |

## Notes
- Caption language: prefers English/Tagalog, otherwise uses whatever caption track exists.
- Framing options: blurred background, crop to fill, or black bars.
- Ranking is a heuristic on caption wording. Always review a moment before posting.
- Before opening this to the public, add rate limiting or sign-in: rendering is CPU-heavy.


## Render free-plan notes
- The service may take about a minute to wake after inactivity.
- Uploaded files are temporary and are deleted when the instance restarts, redeploys, or spins down.
- Video rendering is CPU/RAM intensive. Keep clips short and uploads small.
- YouTube may block caption requests from cloud-hosting IP addresses. `PROXY_URL` is optional and should only be set if you have a legitimate proxy service you are authorized to use; it is not required for the app to start.

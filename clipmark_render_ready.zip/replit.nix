{ pkgs }: {
  deps = [ pkgs.ffmpeg ];
}

import html
import os
import re
import subprocess
import tempfile
import uuid
from urllib.parse import parse_qs, urlparse

from flask import Flask, Response, jsonify, render_template, request
from youtube_transcript_api import YouTubeTranscriptApi

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = int(os.environ.get("MAX_UPLOAD_MB", "100")) * 1024 * 1024

MAX_CLIP_SECONDS = 90
ALLOWED_SUFFIXES = {".mp4", ".mov", ".mkv", ".webm"}
PREFERRED_LANGUAGES = ["en", "en-US", "en-GB", "tl", "fil"]


# --------------------------------------------------------------------------
# YouTube helpers
# --------------------------------------------------------------------------
def get_video_id(url):
    parsed = urlparse((url or "").strip())
    host = re.sub(r"^(www\.|m\.)", "", parsed.netloc.lower())
    if host == "youtu.be":
        return parsed.path.strip("/").split("/")[0] or None
    if host == "youtube.com" or host.endswith(".youtube.com"):
        if parsed.path == "/watch":
            return parse_qs(parsed.query).get("v", [None])[0]
        parts = parsed.path.strip("/").split("/")
        if len(parts) >= 2 and parts[0] in ("shorts", "embed", "live"):
            return parts[1]
    return None


def make_api():
    """Set PROXY_URL if YouTube blocks your host's IP (common on cloud hosts)."""
    proxy = os.environ.get("PROXY_URL")
    if proxy:
        from youtube_transcript_api.proxies import GenericProxyConfig
        return YouTubeTranscriptApi(proxy_config=GenericProxyConfig(http_url=proxy, https_url=proxy))
    return YouTubeTranscriptApi()


def clean_text(text):
    text = html.unescape(str(text))
    text = re.sub(r"\[[^\]]*\]", " ", text)  # [Music], [Applause]
    return re.sub(r"\s+", " ", text).strip()


def fetch_transcript(video_id):
    """Returns (rows, language_name). Uses any available language if no preferred one exists."""
    api = make_api()
    transcript_list = api.list(video_id)
    available = list(transcript_list)
    try:
        chosen = transcript_list.find_transcript(PREFERRED_LANGUAGES)
    except Exception:
        if not available:
            raise
        chosen = available[0]
    fetched = chosen.fetch()
    rows = [
        {"start": float(s.start), "duration": float(s.duration), "text": clean_text(s.text)}
        for s in fetched
    ]
    return [r for r in rows if r["text"]], chosen.language


# --------------------------------------------------------------------------
# Highlight ranking (heuristic)
# --------------------------------------------------------------------------
STRONG_HOOKS = {
    "secret", "crazy", "insane", "wait", "impossible", "finally", "never", "worst",
    "mistake", "truth", "revealed", "surprise", "secretly", "unexpected",
    "destroyed", "shocked", "unbelievable", "incredible", "huge", "nobody",
}
WEAK_HOOKS = {"why", "how", "actually", "best", "biggest", "always", "stop"}
PHRASES = ["but then", "the reason", "turns out", "i can't believe", "you won't believe", "here's the thing"]


def score_window(text):
    low = text.lower()
    words = re.findall(r"[a-zA-Z0-9']+", low)
    if not words:
        return 0.0, []
    score = min(len(words) / 35.0, 1.4)
    found = []
    for w in words:
        if w in STRONG_HOOKS:
            score += 0.45
            found.append(w)
        elif w in WEAK_HOOKS:
            score += 0.15
            found.append(w)
    score += min(text.count("!") * 0.18, 0.7)
    score += min(text.count("?") * 0.12, 0.4)
    if any(p in low for p in PHRASES):
        score += 0.25
    return round(score, 2), sorted(set(found))


def find_highlights(rows, clip_seconds=35, count=5):
    if not rows:
        return [], 0
    duration = max(r["start"] + r["duration"] for r in rows)
    step = max(8, clip_seconds // 3)

    # Start windows on caption boundaries so clips don't open mid-sentence.
    starts, last = [], -1e9
    for r in rows:
        if r["start"] - last >= step:
            starts.append(r["start"])
            last = r["start"]

    candidates = []
    for start in starts:
        limit = start + clip_seconds
        sel = [r for r in rows if start <= r["start"] < limit]
        if not sel:
            continue
        end = min(limit, max(r["start"] + r["duration"] for r in sel))
        if end - start < clip_seconds * 0.6:
            continue
        text = " ".join(r["text"] for r in sel)
        if len(re.findall(r"\w+", text)) < 12:
            continue
        score, hooks = score_window(text)
        candidates.append({
            "start": round(start, 1), "end": round(end, 1), "score": score,
            "hooks": hooks, "text": text[:420],
        })

    candidates.sort(key=lambda c: c["score"], reverse=True)
    chosen = []
    for c in candidates:
        if all(abs(c["start"] - o["start"]) >= clip_seconds * 0.65 for o in chosen):
            chosen.append(c)
        if len(chosen) >= count:
            break
    return sorted(chosen, key=lambda c: c["start"]), duration


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
FILTERS = {
    # Crop to fill the whole 9:16 frame.
    "fill": "[0:v]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1,format=yuv420p[v]",
    # Whole picture, over a blurred copy of itself.
    "blur": ("[0:v]split=2[a][b];"
             "[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=30:3[bg];"
             "[b]scale=1080:1920:force_original_aspect_ratio=decrease[fg];"
             "[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,format=yuv420p[v]"),
    # Whole picture, black bars.
    "fit": ("[0:v]scale=1080:1920:force_original_aspect_ratio=decrease,"
            "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,format=yuv420p[v]"),
}


def err(message, status=400):
    return jsonify(error=message), status


@app.errorhandler(413)
def too_large(_):
    return err("That file is too large. Trim it first or raise MAX_UPLOAD_MB.", 413)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/healthz")
def healthz():
    return "ok"


@app.post("/api/highlights")
def api_highlights():
    data = request.get_json(silent=True) or {}
    video_id = get_video_id(data.get("url", ""))
    if not video_id:
        return err("That doesn't look like a YouTube video link. Paste a youtube.com or youtu.be URL.")
    try:
        clip_seconds = min(max(int(data.get("clip_seconds", 35)), 15), MAX_CLIP_SECONDS)
        count = min(max(int(data.get("count", 5)), 1), 10)
    except (TypeError, ValueError):
        return err("Clip length and count must be numbers.")

    try:
        rows, language = fetch_transcript(video_id)
    except Exception as e:
        name = type(e).__name__
        if name in ("RequestBlocked", "IpBlocked"):
            msg = ("YouTube is blocking caption requests from this server. "
                   "Set the PROXY_URL environment variable and try again.")
        elif name == "TranscriptsDisabled":
            msg = "This video has captions turned off, so there's nothing to analyze."
        elif name in ("VideoUnavailable", "VideoUnplayable"):
            msg = "That video is unavailable. Check that it's public and the link is right."
        else:
            msg = "Couldn't read captions for this video. It may have none, or be restricted."
        app.logger.warning("transcript failure for %s: %s: %s", video_id, name, str(e)[:200])
        return err(msg, 502)

    highlights, duration = find_highlights(rows, clip_seconds, count)
    if not highlights:
        return err("There wasn't enough spoken content to rank moments. Try a shorter clip length.", 422)
    return jsonify(video_id=video_id, duration=duration, language=language, highlights=highlights)


@app.post("/api/render")
def api_render():
    video = request.files.get("video_file")
    framing = request.form.get("framing", "blur")
    try:
        start = float(request.form.get("start", "0"))
        end = float(request.form.get("end", "0"))
    except ValueError:
        return err("Start and end must be numbers of seconds.")
    if not video or not video.filename:
        return err("Choose the video file you want to clip.")
    if start < 0 or end <= start:
        return err("The end time must be after the start time.")
    if end - start > MAX_CLIP_SECONDS:
        return err(f"Clips are limited to {MAX_CLIP_SECONDS} seconds.")
    if framing not in FILTERS:
        return err("Unknown framing option.")
    suffix = os.path.splitext(video.filename)[1].lower()
    if suffix not in ALLOWED_SUFFIXES:
        return err("Upload an MP4, MOV, MKV, or WEBM file.")

    with tempfile.TemporaryDirectory(prefix="clipmark_") as tmp:
        in_path = os.path.join(tmp, uuid.uuid4().hex + suffix)
        out_path = os.path.join(tmp, "clip.mp4")
        video.save(in_path)
        cmd = [
            "ffmpeg", "-y", "-ss", f"{start:.2f}", "-i", in_path, "-t", f"{end - start:.2f}",
            "-filter_complex", FILTERS[framing], "-map", "[v]", "-map", "0:a:0?",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out_path,
        ]
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=300)
        except subprocess.TimeoutExpired:
            return err("Rendering took too long. Try a shorter clip or smaller file.", 504)
        except FileNotFoundError:
            return err("FFmpeg isn't installed on this server.", 500)
        except subprocess.CalledProcessError as e:
            app.logger.warning("ffmpeg failed: %s", e.stderr.decode("utf-8", "ignore")[-400:])
            return err("Couldn't render that file. Check that it plays and that the time range is inside it.", 422)
        with open(out_path, "rb") as f:
            payload = f.read()

    return Response(payload, mimetype="video/mp4",
                    headers={"Content-Disposition": 'attachment; filename="clipmark-clip.mp4"'})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=False, threaded=True)
